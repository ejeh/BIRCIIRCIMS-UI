


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:11:44 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Qingswap - Exchange and Trading</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

    <!-- All CSS Plugins here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/jquery.animatedheadline.css">

    <!-- Custom Css File -->
    <link rel="stylesheet" href="css/classy-nav.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="onitaNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="index.html"><img src="img/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- Menu Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="market.php">Market</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="auth/login.php">Login</a></li>
                                <li><a href="auth/register.php">Register</a></li>
                                <li>
                                    <style type="text/css">
                a.gflag {
                  vertical-align: middle;
                  font-size: 16px;
                  padding: 1px 0;
                  background-repeat: no-repeat;
                  background-image: url(//gtranslate.net/flags/16.png);
                }
                a.gflag img {
                  border: 0;
                }
                a.gflag:hover {
                  background-image: url(//gtranslate.net/flags/16a.png);
                }
                #goog-gt-tt {
                  display: none !important;
                }
                .goog-te-banner-frame {
                  display: none !important;
                }
                .goog-te-menu-value:hover {
                  text-decoration: none !important;
                }
                body {
                  top: 0 !important;
                }
                #google_translate_element2 {
                  display: none !important;
                }
              </style>

              <br /><select onchange="doGTranslate(this);">
                <option value="">Select Language</option>
                <option value="en|zh-CN">Chinese (Simplified)</option>
                <option value="en|zh-TW">Chinese (Traditional)</option>
                <option value="en|en">English</option>
              </select>
              <div id="google_translate_element2"></div>
              <script type="text/javascript">
                function googleTranslateElementInit2() {
                  new google.translate.TranslateElement(
                    { pageLanguage: "en", autoDisplay: false },
                    "google_translate_element2"
                  );
                }
              </script>
              <script
                type="text/javascript"
                src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"
              ></script>

              <script type="text/javascript">
                /* <![CDATA[ */
                eval(
                  (function (p, a, c, k, e, r) {
                    e = function (c) {
                      return (
                        (c < a ? "" : e(parseInt(c / a))) +
                        ((c = c % a) > 35
                          ? String.fromCharCode(c + 29)
                          : c.toString(36))
                      );
                    };
                    if (!"".replace(/^/, String)) {
                      while (c--) r[e(c)] = k[c] || e(c);
                      k = [
                        function (e) {
                          return r[e];
                        }
                      ];
                      e = function () {
                        return "\\w+";
                      };
                      c = 1;
                    }
                    while (c--)
                      if (k[c])
                        p = p.replace(
                          new RegExp("\\b" + e(c) + "\\b", "g"),
                          k[c]
                        );
                    return p;
                  })(
                    "6 7(a,b){n{4(2.9){3 c=2.9(\"o\");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s('t'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a=='')v;3 b=a.w('|')[1];3 c;3 d=2.x('y');z(3 i=0;i<d.5;i++)4(d[i].A=='B-C-D')c=d[i];4(2.j('k')==E||2.j('k').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,'m');7(c,'m')}}",
                    43,
                    43,
                    "||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500".split(
                      "|"
                    ),
                    0,
                    {}
                  )
                );
                /* ]]> */
              </script>
                                </li>
                            </ul>
                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Area End -->
<br>
 <br>
 <br>
 <br>
 <br>
 <br>


<section class="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                       
                        
                        <h3 class="card-title mb-2">ACCEPTANCE OF TERMS OF USE</h3>
                        <p class="card-text mb-3">By using this Site, registering for a Qingswap account ("Account") or using any other services, products, data, content or other material available through the Site ("Services"), you ("you, your, or yourself") are agreeing to accept and comply with the terms and conditions of use stated below ("Terms of Use"). You should read the entire Terms of Use carefully before using this Site or any of the Services.</p>
                        <p class="card-text mb-3">The Services allow registered users of the Services to:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Buy or sell Virtual Assets and Digital Assets from or to other Members in exchange for other Virtual Assets or Digital Assets, or for fiat currency;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Enter into arrangements to store Virtual Assets and Digital Assets listed on the Site with a third-party custodian;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Withdraw any fiat currency balance held in your Account;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Transfer Virtual Assets and Digital Assets to a wallet or to other users of such Virtual Assets and Digital Assets outside the Site;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Use Virtual Assets for purchasing goods; and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Access and use the Ripple protocol.</li>
                        </ul>
                        <p class="card-text mb-3">Depending on your country of residence, you may not be able to use all the functions of the Site or Services. It is your responsibility to follow the rules and laws in your country of residence and/or country from which you access this Site and the Services. As long as you agree to and comply with these Terms of Use. grants you the personal, non-exclusive, non-transferable, non-sublicensable and limited right to enter and use the Site and the Services.</p>
                        <p class="card-text mb-3">&nbsp;</p>
                        <h3 class="card-text mb-3">IF YOU DO NOT ACCEPT THE TERMS OF USE AND CONDITIONS OUTLINED IN THIS AGREEMENT, DO NOT ACCESS THIS SITE AND DO NOT USE THE SERVICES.</h3>
                        <p class="card-text mb-3">&nbsp;</p>
                        <p class="card-text mb-3">By opening an Account, you expressly represent and warrant:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>That you have accepted you are legally bound by these Terms of Use; and</li>
                        <li><i class="fal fa-angle-right mr-2"></i>That you are at least 18 years of age and have the full capacity to accept these Terms of Use and enter into a transaction involving Virtual Assets and other Digital Assets.</li>
                        <li><i class="fal fa-angle-right mr-2"></i>We allow users trade once every 24 hours. It must be strictly adhered to. </li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Sending the wrong quantity results to loss of funds and we won't be held responsible for this loss</li>
                        </ul>
                        <h3 class="card-text mb-3">RISKS</h3>
                        <p class="card-text mb-3">The trading of goods and products, real or virtual, as well as virtual currencies involves significant risk. Prices can and do fluctuate on any given day. Such price fluctuations may increase or decrease the value of your assets at any given moment. Any currency - virtual or not - may be subject to large swings in value and may even become worthless. There is an inherent risk that losses will occur as a result of buying, selling or trading anything on a market.</p>
                        <p class="card-text mb-3">Virtual Asset and Digital Asset trading also has special risks not generally shared with official currencies, goods or commodities in a market. Unlike most currencies, which are backed by governments or other legal entities, or by commodities such as gold or silver, Virtual Assets and Digital Assets are a unique type of asset, backed by technology and trust. There is no central bank that can issue more cryptocurrency or take corrective measures to protect the value of Virtual Assets and Digital Assets in a crisis.</p>
                        <p class="card-text mb-3">Instead, Virtual Assets and Digital Assets are an as-yet autonomous and largely unregulated global system of cryptocurrency firms and individuals. Traders put their trust in a digital, decentralised and partially anonymous system that relies on peer-to-peer networking and cryptography to maintain its integrity.</p>
                        <p class="card-text mb-3">The trading of Virtual Assets and Digital Assets is often susceptible to irrational (or rational) bubbles or loss of confidence, which could collapse demand relative to supply. For example, confidence in Virtual Assets and Digital Assets might collapse because of unexpected changes imposed by software developers or others, a government crackdown, the creation of superior competing alternative currencies, or a deflationary or inflationary spiral. Confidence might also collapse because of technical problems: if the anonymity of the system is compromised, if money is lost or stolen, or if hackers or governments are able to prevent any transactions from settling.</p>
                        <p class="card-text mb-3">There may be additional risks that we have not foreseen or identified in our Terms of Use.</p>
                        <p class="card-text mb-3">You should carefully assess whether your financial situation and tolerance for risk is suitable for buying, selling or trading Virtual Assets or Digital Assets.</p>
                        <p class="card-text mb-3">We use our banking providers in order to facilitate the receipt of fiat currency from Members and payments to other Members. Our banking providers DO NOT transfer, exchange or provide any services in connection with Virtual Assets or Digital Assets. Your fiat currency will be held in a bank account in the name of Qingswap together with other Members' fiat currency. Where possible in a relevant jurisdiction which recognises the concept of a client account, we will notify the relevant banking provider that the bank account is a client account in which we hold fiat currency on behalf of Members. You will, in any event, remain the beneficial owner of the fiat currency that we hold on your behalf. We will maintain detailed records of all fiat currency held on behalf of Members. Whilst Qingswap uses reasonable care in the appointment of its banking providers, in the event of a banking provider becoming insolvent or entering into an insolvency process in a relevant jurisdiction, Qingswap may have only an unsecured claim against the banking provider, and Members' fiat currency balances may be at risk subject to any protections provided at law in the relevant jurisdiction.</p>
                        <p class="card-text mb-3">We engage with third-party custodians in order to hold Virtual Assets and Digital Assets on your behalf. Your Virtual Assets and Digital Assets will be held on your behalf in a wallet in the name of Qingswap together with other Members' Virtual Assets and/or Digital Assets. They may also from time to time be held in the wallet together with Qingswap's Virtual Assets and/or Digital Assets which reflect Qingswap's fees, but which are recorded on Qingswap's ledger as belonging to Qingswap, and which you instruct Qingswap to collect by withdrawing them from the wallet from time to time). We will maintain detailed records of all Virtual Assets and Digital Assets which Members hold with third-party custodians appointed by us.</p>
                        <p class="card-text mb-3">As set out below, Qingswap will act only on your Instructions in respect of Virtual Assets and Digital Assets, and does not otherwise acquire any right, title or interest in them. Whilst Qingswap uses reasonable care in the appointment of third-party custodians, in the event of a third-party custodian becoming insolvent or entering into an insolvency process in a relevant jurisdiction, you may have only an unsecured claim against the third-party custodian, and Members' Virtual Assets or Digital Assets may be at risk subject to any protections provided at law in the relevant jurisdiction.</p>
                        <h3 class="card-text mb-3">LIMITED RIGHT OF USE</h3>
                        <p class="card-text mb-3">Unless otherwise specified, all materials on this Site are the property of Qingswap and are protected by copyright, trademark and other applicable laws. You may view, print and/or download a copy of the materials from this Site on any single computer solely for your personal, informational and/or non-commercial use, provided you comply with all copyright and other proprietary notices.</p>
                        <p class="card-text mb-3">The trademarks, service marks and logos of Qingswap and others used in this Site ("Trademarks'') are the property of Qingswap and their respective owners. The software, text, images, graphics, data, prices, trades, charts, graphs, video and audio used on this Site belong to Qingswap. The Trademarks and material should not be copied, reproduced, modified, republished, uploaded, posted, transmitted, scraped, collected or distributed in any form or by any means, whether manual or automated. The use of any such materials on any other Site or networked computer environment for any other purpose is strictly prohibited; any such unauthorised use may violate copyright, trademark and other applicable laws and could result in criminal or civil penalties.</p>
                        <h3 class="card-text mb-3">MAINTAINING YOUR ACCOUNT: OUR RULES AND ROLE</h3>
                        <p class="card-text mb-3">This Site and the Services are for your personal use only. We are vigilant in maintaining the security of our Site and the Services. By registering with us, you agree to provide Qingswap with current, accurate and complete information about yourself, as prompted by the registration process, and to keep such information updated. You further agree that you will not use any Account other than your own or access the Account of any other Member at any time or assist others in obtaining unauthorised access.</p>
                        <p class="card-text mb-3">Qingswap's role is limited to providing you with a platform via the Services under which we act solely as a service provider, as your agent and in accordance with your Instructions for the management and transfer of Virtual Assets and other Digital Assets. We do not store any Virtual Assets or other Digital Assets directly, but where you Instruct us to arrange for any Virtual Assets or other Digital Assets owned by you (including any bought on your behalf) to be held until we receive further Instruction from you to sell or transfer them (with any deposit of Digital Assets and/or Virtual Assets being deemed to be such an Instruction), we will, acting on your behalf, appoint a third-party as a custodian and to hold the relevant Virtual Assets or other Digital Assets as a custodian in accordance with our agency authority (see below). The custodian services will be provided on terms that apply directly between the custodian and you, and which will be made available to you. Qingswap does not directly provide, charge for and is not responsible for custodian services. Any issues you have relating to custodian services should be taken up by you with the custodians, however, we may, on your behalf, provide assistance in accordance with our agency authority (see below).</p>
                        <p class="card-text mb-3">Notwithstanding the direct custodial relationship between the custodian and you, if for any reason Qingswap is held or declared to have any legal or beneficial interest in your Virtual Assets or other Digital Assets, Qingswap will hold on trust for you all such right title and interest which Qingswap is held or declared to have and will not transfer or sell any Virtual Assets or other Digital Assets other than in accordance with your Instructions (which includes any instructions mandated by law, regulatory authority or enforcement agencies).</p>
                        <p class="card-text mb-3">In order for us to manage the Site, provide the Services and create a direct relationship between you and the third-party custodian to hold the relevant Virtual Assets or other Digital Assets as custodian on your behalf, you appoint Qingswap as your agent with a perpetual and irrevocable (other than in the event of Account termination) agency authority to act as your agent to:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Create a direct legal-custodial relationship between you and a third-party custodian for the custody of your Virtual Assets or other Digital Assets, as well as appointing authorised persons within Qingswap to instruct such third-party custodians on your behalf;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Access and/or transfer Virtual Assets or other Digital Assets as required for the operation of the Site and provision of the Services, including:</li>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Storing and keeping confidential private keys in respect of Virtual Assets or other Digital Assets;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Transferring cryptocurrencies to third-party custodians (who are entitled in turn to appoint sub-custodians and provide the custodian services to you through such sub-custodians or other nominees or agents); and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Moving cryptocurrencies between hot and cold wallets held by these custodians to allow sufficient hot wallet liquidity to support trades on the Site whilst at the same time providing the additional security of cold wallet storage;</li>
                        </ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Share your information with third-party custodian-service providers so that they can be engaged to provide custodian services to you (see below);</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Undertake the following events that act, or could act as restrictions, or impact your rights:</li>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Freezing of Ripple accounts in accordance with Ripple Labs policy;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Termination of our relationship with you and/or your Account;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Suspension of our relationship with you and/or your Account;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Prohibiting wash trading and other activities;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Requiring minimum trade sizes;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Blocking Accounts in certain circumstances;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Applying service downtime and unavailability restrictions;</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Complying with enforcement-agency orders or regulatory actions; and</li>
                        </ul>
                        <li>&nbsp;</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Otherwise act only on your instructions in respect of any Virtual Assets or other Digital Assets, including in respect of:</li>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Any buying or selling of Virtual Assets or other Digital Assets;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>The accessing or transferring of Virtual Assets or other Digital Assets between wallets; and/or</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Any other purpose or action as instructed by you.</li>
                        </ul>
                        </ul>
                        <p class="card-text mb-3">By agreeing to these Terms of Use you acknowledge and agree that in doing so, you instruct us on an irrevocable ongoing basis to undertake all of the above-mentioned actions on your behalf. You cannot revoke this ongoing Instruction except by closing your Account, in which case it will lapse only when your Account is closed. In these Terms of Use, "Instructions" means:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Instructions received or directed via the Site or as received directly from you in any medium other than via the Site, where Qingswap has expressly agreed in writing to accept such instructions from you;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Acts Qingswap may take as set out in these Terms of Use or in any other form of documentation establishing the legal relationship between you and Qingswap, including instructions within the remit of our agency authority set out above (including the Instruction to create the legal custodial relationship with the third-party custodian for the purpose of administering the Services for you); and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Instructions mandated by law, regulatory authority or enforcement agencies.</li>
                        </ul>
                        <p class="card-text mb-3">As a result of this limited agency relationship, we do not, and you agree that we do not, have or acquire any rights, title or interest in any Virtual Assets or other Digital Assets that are held on your behalf by the third-party custodian.</p>
                        <p class="card-text mb-3">We are not an intermediary, do not acquire any rights, title or interest in, and do not assume and have no rights or control over any Virtual Assets or other Digital Assets or any other Member assets other than in respect of actions taken in accordance with our agency authority and your Instructions. As a result, we will not transfer or sell any Virtual Assets or other Digital Assets other than in accordance with your Instructions (which includes any instructions mandated by law, regulatory authority or enforcement agencies).</p>
                        <p class="card-text mb-3">The creation or use of Accounts without obtaining prior express permission from Qingswap will result in the immediate suspension of all said Accounts, as well as all pending purchase/sale offers. Any attempt to do so or to assist others (Members or otherwise), or the distribution of instructions, software or tools for that purpose, will result in the Accounts of such Members being terminated. Termination is not the exclusive remedy for such a violation, and Qingswap may elect to take further action against you.</p>
                        <p class="card-text mb-3">You are also responsible for maintaining the confidentiality of your Account information, including your password, safeguarding your own Virtual Assets and Digital Assets, and all activity including Transactions that are posted to your Account (including all Instructions to Qingswap). Any actions on the Site, transactions, orders, Instructions and operations initiated from your Account or using your password are 
                        <li><i class="fal fa-angle-right mr-2"></i>(1) Considered to have been made by you and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>(2) Irrevocable once validated using your password or made through your Account. </li>
                        <p class="card-text mb-3">If there is suspicious activity related to your Account, we may, but are not obligated to, request additional information from you, including authenticating documents, and freeze any transactions pending our review. You are obligated to comply with these security requests or accept the termination of your Account. You are required to notify Qingswap immediately of any unauthorised use of your Account or password, or any other breach of security, by email to <a href="mailto:support@Qingswap.com">support@Qingswap.com.</a></p>
                        <p class="card-text mb-3"> Any Member who violates these rules may be terminated, and thereafter held liable for losses incurred by Qingswap or any user of the Site and Services.</p>
                        <p class="card-text mb-3">Qingswap similarly reserves the right to freeze Ripple accounts in accordance with the Ripple Labs policy, which took effect on 15 September 2014. Please see the explanation provided by Ripple Labs below:</p>
                        <p class="card-text mb-3">"The freeze protocol extension gives gateways the ability to 1) globally freeze all their issued funds or 2) freeze funds issued to a specific user. Frozen funds may only be sent back to the issuing gateway. The global freeze feature allows a gateway to freeze all balances it issues. The gateway may still issue payments. Accounts holding frozen balances may return the funds to the gateway. This feature is useful for migrating users from one account to another and to safeguard users in the event that the gateway account is compromised. The individual freeze is primarily intended for compliance with regulatory requirements, which may vary from one jurisdiction to another. It also allows gateways to freeze individual accounts issuances in order to investigate suspicious activity. These features allow gateways to better operate in compliance with laws and regulations."</p>
                        <p class="card-text mb-3">You will not take, directly or indirectly, any action designed, or that might reasonably be expected, to cause or result in destabilization or manipulation of the price of Virtual Assets or Digital Assets, which are available on the Site.</p>
                        <p class="card-text mb-3">Qingswap reserves the right to suspend, delay or cancel an Instruction or series of Instructions issued by a Member or colluding Members which if executed would result in a price swing of 5% or more of the value of a cryptocurrency available on the Site.</p>
                        <p class="card-text mb-3">For the avoidance of doubt, any action taken by Qingswap to suspend, delay, cancel or freeze any instructions and/or to suspend your Account will not affect your rights, title or interest in respect of your Virtual Assets and other Digital Assets which are held by a third-party custodian on your behalf, but may affect Qingswap's ability to execute your Instructions, which you hereby acknowledge and agree.</p>
                        <p class="card-text mb-3">You acknowledge that you will only credit your Qingswap account from a bank account that is in your own name and that you will instruct payments from your Qingswap account only to a bank account that is in your own name.</p>
                        <p class="card-text mb-3">We reserve the right to cancel transfers which are made by or sent to third parties.</p>
                        <h3 class="card-text mb-3">Wash Trading</h3>
                        <p class="card-text mb-3">Qingswap does not allow you to cross trade, either alone or in collusion with others or to place an order, which would result in a self-execution - i.e., where the same trader or group of traders would act as both the maker and taker for the trade.</p>
                        <p class="card-text mb-3">If two orders of opposing sides would result in a crossed trade, both orders are subject to specific measures, ranging from scrutiny, cancellation, suspension or prohibition to trade on the Site. If two orders of the same quantity would result in self-execution, both orders are subject to specific measures, ranging from scrutiny, cancellation, suspension or prohibition to trade on the Site.</p>
                        <h3 class="card-text mb-3">Market Manipulation</h3>
                        <p class="card-text mb-3">You are prohibited from engaging or attempting to engage in market manipulation. This prohibition applies to any kind of activity that results in or has the purpose of:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Artificially controlling or manipulating the price or trading volume of any of the virtual currencies listed on the Site; and</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Manipulating of a benchmark, including, but not limited to, the transmission of false or misleading inputs, or any other action that manipulates the calculation of a benchmark.</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Arbitraging digital assets as individual account user, including, possible attempts of laundering stolen funds from third-party exchange platforms</li>
                        </ul>
                        <p class="card-text mb-3">Market manipulation will trigger specific measures, ranging from scrutiny, cancellation of orders, suspension or prohibition to trade on the Site and disclosure to third parties including full disclosure to competent authorities.</p>
                        <p class="card-text mb-3">Lastly, you agree not to use the Services to perform criminal activity of any sort, including but not limited to, money laundering, illegal gambling operations, terrorist financing, malicious hacking or any criminal or illegal activity.</p>
                        <p class="card-text mb-3">The minimum trade size is defined by the Qingswap Fee Schedule.</p>
                        <p class="card-text mb-3">The accounts that were or will be funded did not and will not earn interests.</p>
                        <h3 class="card-text mb-3">ARBITRAGING DIGITAL ASSETS</h3>
                        <p class="card-text mb-3">Qingswap forbids individual accounts to perform digital asset arbitrage - i.e. depositing funds from third-party exchange service with only purpose to perform exchange and withdraw funds to a third-party exchange gaining profit on price differencies between Qingswap and third-party exchange Services due to high possibility of money laundering activity. Qingswap reserves the right to shut down that kind of activity by freezing arbitraged funds and forcing you to upgrade your account to Institutional. Qingswap reserves the right to freeze your account untill you follow the conditions of this term. Individual account, upgraded to Institutional, or account registered as Institutional is exempted of following this requirement. Qingswap will not charge you any fees for upgrading your account to Institutional while being frozen for performing this kind of activity.</p>
                        <h3 class="card-text mb-3">COMMISSIONS</h3>
                        <p class="card-text mb-3">Qingswap Commissions are available in our Fee Schedule. Qingswap reserves the right to change its Commissions at any time and at its sole discretion. You will be notified of any changes in advance through your Account or Email. Upon such notification, it is your responsibility to review the amended Fee Schedule. Your continued use of the Site following the posting of a notice of Commission changes signifies that you accept and agree to the changes. Qingswap will not charge you any fees other than the Qingswap Commissions and other fees set out in the Fee Schedule. Qingswap may not use the Digital Assets and/or Virtual Assets in any way to generate revenue other than in connection with the charging of fees as set out in the Fee Schedule.</p>
                        <h3 class="card-text mb-3">VERIFICATION OF ACCOUNTS</h3>
                        <p class="card-text mb-3">The creation and use of your Account are subject to verifications, as required by statutory and regulatory obligations incumbent on Qingswap. You agree to provide us with the information we request for the purposes of identity verification, compliance with know-your-customer rules, as well as detection of money laundering, terrorism financing, fraud or any other financial crime. The requested information may include Personal Data (please refer to our Privacy Policy ). </p>

                        <p class="card-text mb-3">By providing us with the information we request, you confirm Qingswap exchange platform as made available on websites that it is true and accurate, and agree to inform us in case of change concerning such information. Your Account will be blocked until we are satisfied with the information you have provided and determine in our sole discretion that it is sufficient to validate your Account. In the meantime, you will not be allowed to terminate your Account or request the deletion of the Personal Data processed in the course of verification operations.</p>

                        <h3 class="card-text mb-3">TERMINATION AND ESCROW OF UNVERIFIED ACCOUNTS</h3>
                        <p class="card-text mb-3">You may terminate this agreement with Qingswap and close your Account at any time, following settlement of any pending Transactions.</p>
                        <p class="card-text mb-3">You also agree that Qingswap may, by giving notice, in its sole discretion terminate your access to the Site and to your Account, including without limitation, its right to: limit, suspend or terminate the Services and Members' Accounts, prohibit access to the Site, the Services and its content, services and tools, delay or remove hosted content, and take technical and legal steps to keep Members off the Site if we suspect that they are creating problems or possible legal liabilities, infringing the intellectual property rights of third parties, or acting inconsistently with the letter or spirit of these Terms of Use. </p>
                        <p class="card-text mb-3">Additionally, we may, in appropriate circumstances and at our discretion, suspend or terminate Accounts of Members for any reason, including without limitation: (1) attempts to gain unauthorised access to the Site or another Member's account or providing assistance to others attempting to do so, (2) overcoming software security features limiting use of or protecting any content, (3) usage of the Services to perform illegal activities such as money laundering, illegal gambling operations, financing terrorism or other criminal activities, (4) violations of these Terms of Use, (5) a failure to pay or a fraudulent payment for Transactions, (6) unexpected operational difficulties, or (7) upon the request of law enforcement or other government agencies.</p>
                        <p class="card-text mb-3">Qingswap expressly reserves the right to cancel and/or terminate Accounts that have not been verified by a Member despite efforts made in good faith by Qingswap to contact said Member to obtain such verification ("Unverified Accounts''). All Unverified Accounts which have been inactive for a period of 6 months or more are further subject to transfer to a third-party escrow ("Unverified Escrow''), and will no longer be maintained or under the legal responsibility of Qingswap. The administrator/trustee of the Unverified Escrow shall make any and all additional reasonable efforts required by law to determine and contact each Unverified Account owner and, after suitable effort and time has been expended, we may be required to convert the residual Virtual Assets or other Digital Assets into fiat and send the converted amount to a national authority responsible for the safekeeping of such funds.</p>
                        <p class="card-text mb-3">The suspension or escrow of an Account shall not affect the payment of commissions due for past Transactions. Upon termination, Members shall send to Qingswap details of a valid bank account to allow for the transfer of any fiat currencies credited to their account. This bank account must be held by and in the name of the Member. Virtual Assets or other Digital Assets may be transferred to a valid bank account only after conversion into a fiat currency. Qingswap shall facilitate the transfer of the currencies as soon as possible following the Member's request and within the time frames specified by Qingswap.</p>
                        <p class="card-text mb-3">Qingswap will arrange to send you the credit balance of your Account; however, in certain circumstances a number of intermediaries may be involved in an international payment and these or the beneficiary bank may deduct charges. We will make all reasonable efforts to ensure that such charges are disclosed to you prior to sending your payment; however, where they cannot be avoided, you acknowledge that these charges cannot always be calculated in advance, and that you agree to be responsible for such charges.</p>
                        <p class="card-text mb-3">Upon Account closure, any amount less than 25 USD/EUR in value will not be returned.</p>
                        <h3 class="card-text mb-3">AVAILABILITY OF SERVICES</h3>
                        <p class="card-text mb-3">All Services are provided without warranty of any kind, either express or implied, and in particular without implied warranties of merchantability and fitness for a particular purpose. We do not represent that this Site or the Services, or the services of any third-party custodian, will be available 100% of the time to meet your needs. We will strive to provide you with the Services as soon as possible, but there are no guarantees that access will not be interrupted, or that there will be no delays, failures, errors, omissions or a loss of transmitted information.</p>
                        <p class="card-text mb-3">We will use reasonable endeavours to ensure that the Site and the Services can be accessed by you in accordance with these Terms of Use. However, we may suspend the use of the Site and the Services for maintenance and will make reasonable efforts to give you notice of this. You acknowledge that this may not be possible in an emergency, and accept the risks associated with the fact that you may not always be able to use the Site and the Services or carry out urgent transactions using your Account.</p>
                        <h3 class="card-text mb-3">APIS AND WIDGETS</h3>
                        <p class="card-text mb-3">We may provide access to certain parties to access specific data and information through our API (Application Programming Interface) or widgets. We also may provide widgets for your use to enter our data on your Site. You are free to use these in their original unmodified and unaltered state.</p>
                        <h3 class="card-text mb-3">EXTERNAL WEBSITES</h3>
                        <p class="card-text mb-3">Qingswap makes no representations whatsoever about any External Websites you may access through the Site including the websites of any third-party custodian service providers. Occasionally, the Qingswap website may provide references or links to External Websites. We do not control these External Websites or third-party sites or any of the content contained therein. You agree that we are in no way responsible or liable for the External Websites referenced or linked from the Qingswap website, including, but not limited to, website content, policies, failures, promotions, products, opinions, advice, statements, prices, activities, advertisements, services or actions and/or any damages, losses, failures or problems caused by, related to or arising from those sites. You shall bear all risks associated with the use of such content.</p>
                        <p class="card-text mb-3">External Websites have separate and independent terms of use and related policies. We request that you review the policies, rules, terms and regulations of each site that you visit. It is up to you to take precautions to ensure that whatever you select for your use is free of items such as viruses, worms, Trojan horses and other items of a destructive nature.</p>
                        <h3 class="card-text mb-3">FINANCIAL ADVICE</h3>
                        <p class="card-text mb-3">For the avoidance of doubt, we do not provide any investment advice in connection with the Services described in these Terms of Use. We may provide information on the price, range and volatility of Virtual Assets and other Digital Assets that are available on our Site and events that have affected the price of such Virtual Assets and Digital Assets, but this must not be considered investment advice nor should it be construed as such. Any decision to purchase or sell Virtual Assets and other Digital Assets is solely your decision and we shall not be liable for any loss suffered.</p>
                        <h3 class="card-text mb-3">FINANCIAL REGULATION</h3>
                        <p class="card-text mb-3">Our business model and our Services facilitate the buying, selling and trading of Virtual Assets and other Digital Assets and their use to purchase goods in an unregulated, international open payment system. The Services we provide are currently unregulated within the UK.</p>
                        <h3 class="card-text mb-3">Qingswap’S APPROACH TO DIGITAL FORKS IN VIRTUAL ASSETS</h3>
                        <p class="card-text mb-3">Qingswap has no control over the software protocols which govern or constitute the framework of Virtual Assets or other Digital Assets. Therefore, Qingswap assumes no responsibility for the update or any modification of the underlying protocols, and Qingswap is not able to guarantee their functionality, security or availability.</p>
                        <p class="card-text mb-3">By accepting the present Terms of Use, you acknowledge and accept the risk that underlying software protocols relating to any of the virtual currencies available on the Site are likely to be subject to sudden changes in operating rules (hereafter "fork"), and such forks may materially affect the value, function and/or the name of the virtual currencies that are exchanged or acquired through the Site.</p>
                        <p class="card-text mb-3">Qingswap will use reasonable endeavours to provide you with notice of forks by publishing such a notice on the Site, including, to the extent possible, whether Qingswap intends to support either or both branches of a fork, and you agree that you will read such notices in order to make a decision in that respect.</p>
                        <p class="card-text mb-3">However, it is your responsibility to make yourself aware of, and consider how to deal with, upcoming forks, including whether to give us Instructions for the withdrawal of the balance of any Virtual Assets or other Digital Assets. In the event of a fork, there is a risk that Qingswap may need to temporarily suspend operations in relation to that fork without providing advance notice to you. Qingswap may in their reasonable discretion, decline to support either or both branches of a fork.</p>
                        <p class="card-text mb-3">You acknowledge that third-party custodian-service providers may operate fork policies and, under their terms as entered into with you in respect of custodian services, may not be obliged (or able) to support all or any forks. You should ensure you check their fork policies regularly (as well as the terms of your agreement with custodian-service providers instructed by Qingswap on your behalf, which will be made available to you) and whenever you become aware of a forthcoming fork. Notwithstanding that a third-party custodian-service provider may support a particular cryptocurrency, including a fork, this will not oblige Qingswap to support that cryptocurrency or fork.</p>
                        <p class="card-text mb-3">In the event of a fork which affects Virtual Assets or other Digital Assets pursuant to these Terms of Use, and which is unsupported by Qingswap:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Qingswap will not acquire any right, title or interest in the unsupported forked Virtual Asset and/or other Digital Assets; and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Qingswap may be unable to give effect to any Instructions given in respect of those Virtual Assets or other Digital Assets and Qingswap will have no liability to you in respect of the unsupported forked Virtual Assets or other Digital Assets.</li>
                        </ul>
                        <p class="card-text mb-3">In the event that Qingswap subsequently decides to support the forked Virtual Assets or other Digital Assets, Qingswap will then give effect to your Instructions</p>
                        <p class="card-text mb-3">By agreeing to the present Terms of Use, you acknowledge the risks presented by forks and you accept that Qingswap has no responsibility to assist you to move or sell Virtual Assets or other Digital Assets of an unsupported branch of a forked protocol.</p>
                        <h3 class="card-text mb-3">EMAIL</h3>
                        <p class="card-text mb-3">Unencrypted email messages sent over the Internet are not secure, and Qingswap is not responsible for any damages incurred by the result of sending email messages in this way. We suggest sending email in encrypted formats; you are welcome to send PGP encrypted emails to us. The instructions and keys to do so are available upon request.</p>
                        <p class="card-text mb-3">If you send unencrypted or unsecured email or other types of communications to us, we may respond using the same channels, and you hereby accept the risks associated therewith.</p>
                        <h3 class="card-text mb-3">DATA PROTECTION</h3>
                        <p class="card-text mb-3">Privacy is very important to us. Full details of our Privacy Policy can be found at Privacy Policy. We recommend that you read the Privacy Policy carefully, so that you know the data that we collect, how we use the data and who we share your data with.</p>
                        <h3 class="card-text mb-3">DISCLOSURES TO LEGAL AUTHORITIES AND AUTHORISED FINANCIAL INSTITUTIONS</h3>
                        <p class="card-text mb-3">We may share your Personal Data with law enforcement, data protection authorities, government officials and other authorities when:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>Required by law;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Compelled by subpoena, court order or other legal procedure;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>We believe that disclosure is necessary to prevent damage or financial loss;</li>
                        <li><i class="fal fa-angle-right mr-2"></i>Disclosure is necessary to report suspected illegal activity; or</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>Disclosure is necessary to investigate violations of our Terms of Use or Privacy Policy</li>
                        </ul>
                        <p class="card-text mb-3">We may also share information concerning US citizens who are Qingswap customers with other financial institutions, as authorised under Section 314(b) of the US Patriot Act, and with tax authorities, including the US Internal Revenue Service, pursuant to the Foreign Account Tax Compliance Act ("FATCA"), to the extent that this statute may be determined to apply to.</p>
                        <p class="card-text mb-3">For further information on how we process your Personal Data, please refer to the Privacy Policy.</p>
                        <h3 class="card-text mb-3">INTERNATIONAL TRANSFERS OF PERSONAL DATA</h3>
                        <p class="card-text mb-3">We store and process your Personal Data in data centres around the world, wherever Qingswap facilities or service providers are located. As such, we may transfer your Personal Data outside of the European Economic Area ("EEA"). Such transfers are undertaken in accordance with our legal and regulatory obligations.</p>
                        <p class="card-text mb-3">Please refer to our Privacy Policy for further details.</p>
                        <h3 class="card-text mb-3">JURISDICTION</h3>
                        <p class="card-text mb-3">The Terms of Use shall be governed and construed in accordance with the law of England and Wales. The parties hereto agree to irrevocably submit to the exclusive jurisdiction of the courts of England and Wales.</p>
                        <h3 class="card-text mb-3">LIMITATION OF LIABILITY</h3>
                        <p class="card-text mb-3">To the extent permitted by law, Qingswap will not be held liable for any damages, loss of profit, loss of revenue, loss of business, loss of opportunity, loss of data, indirect or consequential loss unless the loss suffered arose from gross negligence, wilful deceit or fraud. Nothing in these terms excludes or limits the liability of either party for fraud, death or personal injury caused by negligence which may not be limited or excluded by law. Although Qingswap endeavours to provide accurate and timely information on the Site, the Site may not always be entirely accurate, complete or current and may include errors. Qingswap may change or update the Site at any time without notice, and you should accordingly verify with independent sources all information before relying on it to take decisions or actions. You remain entirely responsible for your decisions and actions. Subject to the above, you also agree and acknowledge that Qingswap has no liability or responsibility in respect of the custody of any Virtual Assets and/or Digital Assets.</p>
                        <p class="card-text mb-3">Subject to the foregoing, Qingswap's aggregate liability for claims based on events arising out of or in connection with any single Member's use of the Site and/or Services, whether in contract, tort (including negligence) or otherwise, shall in no circumstances exceed the greater of either (a) the total amount held on the Account of the Member making a claim less any amount of Commission that may be due and payable in respect of such an Account, or (b) 125% of the amount of the Transaction(s) that are the subject of the claim less any amount of Commission that may be due and payable in respect of such Transaction(s).</p>
                        <h3 class="card-text mb-3">INDEMNITY</h3>
                        <p class="card-text mb-3">To the full extent permitted by applicable law, you hereby agree to indemnify Qingswap and its partners against any action, liability, cost, claim, loss, damage, proceeding or expense suffered or incurred if directly or not directly arising from your use of the Site, your use of the Services or from your violation of these Terms of Use.</p>
                        <h3 class="card-text mb-3">TAXES</h3>
                        <p class="card-text mb-3">It is your responsibility to determine whether, and to what extent, any taxes apply to any transactions you and your Company conduct through the Services, and to withhold, collect, report and remit the correct amounts of taxes to the appropriate tax authorities. Your transaction history is available through your Account.</p>
                        <h3 class="card-text mb-3">MISCELLANEOUS</h3>
                        <p class="card-text mb-3">If we are unable to perform the Services outlined in the Terms of Use due to factors beyond our control including but not limited to an event of Force Majeure, change of law or change in sanctions policy, we shall not be liable for the Services provided under this agreement during the time period coincident with the event.</p>
                        <h3 class="card-text mb-3">MODIFICATION OF TERMS</h3>
                        <p class="card-text mb-3">Qingswap reserves the right to change, add or remove parts of these Terms at any time and at its sole discretion. You will be notified of any changes in advance through your Account. Upon such notification, it is your responsibility to review the amended Terms. Your continued use of the Site and the Services following the posting of a notice of changes to the Terms signifies that you accept and agree to the changes, and that all subsequent transactions by you will be subject to the amended Terms.</p>
                        <h3 class="card-text mb-3">Transfer</h3>
                        <p class="card-text mb-3">Qingswap may transfer its rights and obligations under the Terms of Use to other entities of the Qingswap Ltd. This includes any other firm or business entity that directly or indirectly acquires all or substantially all of the assets or business of Qingswap Ltd. Any transfer of the rights and obligations of Qingswap Ltd to other entities in the Qingswap Ltd. will be binding upon you. If you do not consent to any transfer, you may terminate this agreement and close your Account.</p>
                        <h3 class="card-text mb-3">DEFINITIONS</h3>
                        <p class="card-text mb-3">Account. The contractual arrangement wherein an individual has accepted the Qingswap Terms of Use, Fee Schedule and Privacy Policy, and received approval to use the Services, including the purchase and sale of Virtual Assets and other Digital Assets, and to perform associated Transactions.</p>
                        <p class="card-text mb-3">Buyer(s). Member(s) that submit an offer to buy Virtual Assets or other Digital Assets through the Services.</p>
                        <p class="card-text mb-3">Commission(s). The fee which is payable to Qingswap, including on each Transaction, such as a Purchase Transaction, and as further defined in the Fee Schedule.</p>
                        <p class="card-text mb-3">Member(s). Buyers and Sellers as well as any holder of an Account.</p>
                        <p class="card-text mb-3">Digital Asset(s). Digitized right to use in a binary format.</p>
                        <p class="card-text mb-3">Digital Asset(s) Arbitrage. Transferring and exchanging funds at Qingswap from&amp;to third-party exchanges with possible purpose to launder stolen funds or gaining profit on price differences between Qingswap and third-party exchange Services.</p>
                        <p class="card-text mb-3">External Website(s). Websites not owned or operated by Qingswap.</p>
                        <p class="card-text mb-3">Member(s). Refers to Buyers and Sellers as well as any registered holders of an Account.</p>
                        <p class="card-text mb-3">Personal Data. Any information relating to an identified or identifiable natural person. An identifiable natural person is one who can be identified, directly or indirectly, in particular by reference to an identifier such as a name, an identification number, location data or an online identifier, or to one or more factors specific to the physical, physiological, genetic, mental, economic, cultural or social identity of that natural person.</p>
                        <p class="card-text mb-3">Price. The "price per coin" for which Members are willing to buy or sell Virtual Assets or other Digital Assets. The Price may be expressed in any of the currencies deposited by Members in their Account and supported by the Services. See our Site for a full list of currencies.</p>
                        <p class="card-text mb-3">Seller(s). Member(s) that submit an offer to sell Virtual Assets or other Digital Assets through the Services.</p>
                        <p class="card-text mb-3">Service(s). The technological platform, functional rules and market managed by Qingswap to permit Sellers and Buyers to purchase and sell Virtual Assets.</p>
                        <p class="card-text mb-3">Site. Qingswap exchange platform as made available on websites <a href="https://Qingswap.com/" class="card-text mb-3">Qingswap.com</a></p>
                        <p class="card-text mb-3">Transaction. Includes the following:</p>
                        <ul>
                        <li><i class="fal fa-angle-right mr-2"></i>The agreement between the Buyer and the Seller to exchange currencies, Virtual Assets or other Digital Assets through the Services for currencies at a commonly agreed rate ("Purchase Transaction");</li>
                        <li><i class="fal fa-angle-right mr-2"></i>The exchange of fiat currencies and Virtual Assets between Members ("Conversion Transaction");</li>
                        <li><i class="fal fa-angle-right mr-2"></i>The exchange of Virtual Assets between Members ("Transfer Transaction"); and</li>
                        <li class="card-text mb-3"><i class="fal fa-angle-right mr-2"></i>The exchange of fiat currencies among Members ("Currency Transfer Transaction").</li>
                        </ul>
                        <p class="card-text mb-3">Qingswap may not offer all these transaction types at this time or at all locations.</p>
                        <p class="card-text mb-3">Transaction Price. The total price paid by the Buyer for each Transaction performed through the Services.</p>
                        <p class="card-text mb-3">Virtual Asset(s). Digital representation of value that can be digitally traded, or transferred, and can be used for payment or investment purposes. Virtual Assets such as cryptocurrencies are a form of Virtual Asset designed to work as a medium of exchange that uses strong cryptography to secure financial transactions, control the creation of additional units and verify the transfer of assets. Virtual Assets use decentralised control as opposed to centralised digital currencies and central banking systems.</p>
                                    </div>
                                </div><!-- end input-group -->
                            </form>
                        </div>
                    </div><!-- end card -->
                    
                    
                </div><!-- end sidebar -->
            </div><!-- end col-lg-4 -->
        </div><!-- end row -->
    </div>
</section>


<!-- Footer Contact Area -->
    <div class="footer-contact-area section-padding-100-50">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Footer Widget -->
                <div class="col-sm-4 col-md-5">
                    <div class="footer-single-widget first mb-50">
                        <div class="footer-logo">
                            <a href="#"><img src="img/footer-logo.png" alt=""></a>
                        </div>
                        <p class="mt-30">Exchange and Trading</p>

                        <div class="footer-form">
                            
                        </div>

                    </div>
                </div>

                <div class="col-sm-8 col-md-7">
                    <div class="row">
                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>LEGAL</h4>
                                <ul>
                                    <li><a href="aml-cft-policy.php">AML&amp;CFT Policy</a></li>
                                            <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                            <li><a href="risk-warning.php">Risk Warning</a></li>
                                            <li><a href="terms-of-services.php">Term of Services</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>SERVICES</h4>
                                <ul>
                                    <li><a href="app/exchange.php">Exchange</a></li>
                                    <li><a href="market.php">Markets</a></li>
                                    <li><a href="app/referrals.php">Referral Program</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-12 col-md-6 col-xl-4">
                            <div class="footer-single-widget mb-50">
                                <h4>Contact info</h4>
                                <ul>
                                    
                                    <li><a href="#"><i class="ti-email"></i>support@qingswap.com</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Contact Area -->

    <!-- Copy Right Area -->
    <div class="copy-right-area">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Copy Right Content -->
                <div class="col-md-6 text-center">
                    <div class="copy-right-content">
                        <p>Copyright © By Qingswap 2023. All right reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="//code.tidio.co/bpnp4xkz2axqrebqxcezgdca9yot1iyn.js" async></script>    <!-- JS here -->
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/jquery.animatedheadline.min.js"></script>
    <script src="js/date-time.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/bundle.js"></script>


    <!-- Custom js-->
    <script src="js/main.js"></script>


</body>


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:12:09 GMT -->
</html>