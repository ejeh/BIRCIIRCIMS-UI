


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:11:44 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Qingswap - Exchange and Trading</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

    <!-- All CSS Plugins here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/jquery.animatedheadline.css">

    <!-- Custom Css File -->
    <link rel="stylesheet" href="css/classy-nav.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="onitaNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="index.html"><img src="img/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- Menu Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="market.php">Market</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="auth/login.php">Login</a></li>
                                <li><a href="auth/register.php">Register</a></li>
                                <li>
                                    <style type="text/css">
                a.gflag {
                  vertical-align: middle;
                  font-size: 16px;
                  padding: 1px 0;
                  background-repeat: no-repeat;
                  background-image: url(//gtranslate.net/flags/16.png);
                }
                a.gflag img {
                  border: 0;
                }
                a.gflag:hover {
                  background-image: url(//gtranslate.net/flags/16a.png);
                }
                #goog-gt-tt {
                  display: none !important;
                }
                .goog-te-banner-frame {
                  display: none !important;
                }
                .goog-te-menu-value:hover {
                  text-decoration: none !important;
                }
                body {
                  top: 0 !important;
                }
                #google_translate_element2 {
                  display: none !important;
                }
              </style>

              <br /><select onchange="doGTranslate(this);">
                <option value="">Select Language</option>
                <option value="en|zh-CN">Chinese (Simplified)</option>
                <option value="en|zh-TW">Chinese (Traditional)</option>
                <option value="en|en">English</option>
              </select>
              <div id="google_translate_element2"></div>
              <script type="text/javascript">
                function googleTranslateElementInit2() {
                  new google.translate.TranslateElement(
                    { pageLanguage: "en", autoDisplay: false },
                    "google_translate_element2"
                  );
                }
              </script>
              <script
                type="text/javascript"
                src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"
              ></script>

              <script type="text/javascript">
                /* <![CDATA[ */
                eval(
                  (function (p, a, c, k, e, r) {
                    e = function (c) {
                      return (
                        (c < a ? "" : e(parseInt(c / a))) +
                        ((c = c % a) > 35
                          ? String.fromCharCode(c + 29)
                          : c.toString(36))
                      );
                    };
                    if (!"".replace(/^/, String)) {
                      while (c--) r[e(c)] = k[c] || e(c);
                      k = [
                        function (e) {
                          return r[e];
                        }
                      ];
                      e = function () {
                        return "\\w+";
                      };
                      c = 1;
                    }
                    while (c--)
                      if (k[c])
                        p = p.replace(
                          new RegExp("\\b" + e(c) + "\\b", "g"),
                          k[c]
                        );
                    return p;
                  })(
                    "6 7(a,b){n{4(2.9){3 c=2.9(\"o\");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s('t'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a=='')v;3 b=a.w('|')[1];3 c;3 d=2.x('y');z(3 i=0;i<d.5;i++)4(d[i].A=='B-C-D')c=d[i];4(2.j('k')==E||2.j('k').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,'m');7(c,'m')}}",
                    43,
                    43,
                    "||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500".split(
                      "|"
                    ),
                    0,
                    {}
                  )
                );
                /* ]]> */
              </script>
                                </li>
                            </ul>
                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Area End -->
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
<section class="coin-list" style="background: white;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 text-center wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s">
                    <div class="section-head">
                        <h4 class="lasthead">Market</h4>
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="col-lg-12 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.5s">
                    <div class="about-testimonial">
                        <div class="table-responsive">

        <table class="table table-striped custom-table">
          <thead>
            <tr>
              
              <th scope="col"></th>
              <th scope="col">Name</th>
              <th scope="col">Price</th>
              <th scope="col">Market Cap</th>
              <th scope="col"></th>
            
            </tr>
          </thead>
          <tbody>
            <tr scope="row">

              
                      
                      <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1.png" alt="" border=0 height="25" width="25">
                      
                      <td><font color="#000000">Bitcoin<br><b>BTC</b></font></td>
                      <td><font color="#000000">$23,956.86</font></td>
                      <td><font color="#000000">$431,973,038,374.84</td>
            <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>

            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Ethereum<br><b>ETH</b></font></td>
                      <td><font color="#000000">$1,689.55</font></td>
                      <td><font color="#000000">$189,296,876,993.36</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1831.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">BitcoinCash<br><b>BCH</b></font></td>
                      <td><font color="#000000">$101.68</font></td>
                      <td><font color="#000000">$424,219,809,261.72</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Litecoin<br><b>LTC</b></font></td>
                      <td><font color="#000000">$81.64</font></td>
                      <td><font color="#000000">$5,375,531,789.30</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            
            <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Litecoin<br><b>LTC</b></font></td>
                      <td><font color="#000000">$278.70</font></td>
                      <td><font color="#000000">$17,065,277,476.67</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>

            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/74.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Dogecoin<br><b>DOGE</b></font></td>
                      <td><font color="#000000">$0.06</font></td>
                      <td><font color="#000000">$9,210,271,731.00</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1958.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Tron<br><b>TRX</b></font></td>
                      <td><font color="#000000">$0.07</font></td>
                      <td><font color="#000000">$6,268,836,030.00</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            <tr>
              
              <td>
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/52.png" alt="" border=0 height="25" width="25">
                      </td>
                      <td><font color="#000000">Ripple<br><b>XRP</b></font></td>
                      <td><font color="#000000">$0.39</font></td>
                      <td><font color="#000000">$17,599,439,039.00</td>
                      <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
            </tr>
            
            <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/131.png" alt="" border=0 height="25" width="25">   
		  <td><font color="#000000">Dash<br><b>DASH</b></font></td>
          <td><font color="#000000">$52.77</font></td>
          <td><font color="#000000">$519,292,989.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
		
          <td>
		  <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1437.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000">Zcash<br><b>ZEC</b></font></td>
          <td><font color="#000000">$66.41</font></td>
          <td><font color="#000000">$779,337,532.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
		
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/512.png" alt="" border=0 height="25" width="25">     
          <td><font color="#000000">Stellar<br><b>XLM</b></font></td>
          <td><font color="#000000">$0.12</font></td>
           <td><font color="#000000">$2,841,737,401.00</td>
           <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/109.png" alt="" border=0 height="25" width="25"> 
          <td><font color="#000000">DigiByte<br><b>DGB</b></font></td>
          <td><font color="#000000">$0.01</font></td>
          <td><font color="#000000">$172,540,041.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/6636.png" alt="" border=0 height="25" width="25">
		  <td><font color="#000000">Polkadot<br><b>DOT</b></font></td>
          <td><font color="#000000">$8.15</font></td>
          <td><font color="#000000">$8,507,783,528.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/328.png" alt="" border=0 height="25" width="25">  
		  <td><font color="#000000">Monero<br><b>XMR</b></font></td>
          <td><font color="#000000">$162.36</font></td>
          <td><font color="#000000">$2,728,236,819.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/7278.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000"> Aave<br><b>AAVE</b></font></td>
          <td><font color="#000000">$106.59</font></td>
          <td><font color="#000000">$1,329,483,386.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2577.png" alt="" border=0 height="25" width="25"></td>     
		  <td><font color="#000000">RavenCoin<br><b>RVN</b></font></td>
          <td><font color="#000000">$0.03</font></td>
          <td><font color="#000000">$318,912,830.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        
        <tr>                    
<td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2010.png" alt="" border=0 height="25" width="25">
<td><font color="#000000">Cardano<br><b>ADA</b></font></td>        
          <td><font color="#000000">$0.53</font></td>
          <td><font color="#000000">$16,752,048,580.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
		
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/825.png" alt="" border=0 height="25" width="25">
		  <td><font color="#000000">Tether<br><b>USDT</b></font></td>
          <td><font color="#000000">$0.93</font></td>
          <td><font color="#000000">$60,665,406,988.74</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>          
        </tr>
		
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/4172.png" alt="" border=0 height="25" width="25"> 
		  <td><font color="#000000">Terra<br><b>LUNA</b></font></td>
          <td><font color="#000000">$0.00</font></td>
          <td><font color="#000000">$0.00</td>
           <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>         
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1975.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000">Chainlink<br><b>LINK</b></font></td>
          <td><font color="#000000">$7.65</font></td>
          <td><font color="#000000">$3,252,703,987.00</td>
           <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>        
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/3794.png" alt="" border=0 height="25" width="25">
		  <td><font color="#000000">Cosmos<br><b>ATOM</b></font></td>
          <td><font color="#000000">$11.98</font></td>
          <td><font color="#000000">$3,215,347,532.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                  
</tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2011.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000">Tezos<br><b>XTZ</b></font></td>
          <td><font color="#000000">$1.80</font></td>
          <td><font color="#000000">$1,493,403,171.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
		
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1274.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000">Waves<br><b>WAVES</b></font></td>
          <td><font color="#000000">$5.98</font></td>
          <td><font color="#000000">$563,988,810.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
		
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/2565.png" alt="" border=0 height="25" width="25">    
		  <td><font color="#000000">Ontology<br><b>ONT</b></font></td>
          <td><font color="#000000">$0.27</font></td>
          <td><font color="#000000">$216,956,560.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                  
</tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1567.png" alt="" border=0 height="25" width="25">     
		  <td><font color="#000000">Nano<br><b>NANO</b></font></td>
          <td><font color="#000000">$1.05</font></td>
          <td><font color="#000000">$126,917,378.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                  
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1886.png" alt="" border=0 height="25" width="25">
          <td><font color="#000000">Dent<br><b>DENT</b></font></td>
          <td><font color="#000000">$0.00</font></td>
          <td><font color="#000000">$103,551,903.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                   
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/7288.png" alt="" border=0 height="25" width="25">     </td>
          <td><font color="#000000">Venus<br><b>XVS</b></font></td>
          <td><font color="#000000">$5.87</font></td>
          <td><font color="#000000">$318,912,830.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5804.png" alt="" border=0 height="25" width="25">     
		  <td><font color="#000000">DeFiChain<br><b>DFI</b></font></td>
          <td><font color="#000000">$1.25</font></td>
          <td><font color="#000000">$626,176,155.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                    
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5802.png" alt="" border=0 height="25" width="25">     
		  <td><font color="#000000">Sora<br><b>XOR</b></font></td>
          <td><font color="#000000">$4.67</font></td>
          <td><font color="#000000">$4,703,593.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/8387.png" alt="" border=0 height="25" width="25">
		  <td><font color="#000000"> Auto<br><b>AUTO</b></font></td>
          <td><font color="#000000">$347.81</font></td>
          <td><font color="#000000">$23,553,111.00</td>
          <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>
                    
        </tr>
        <tr>
          <td><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/4200.png" alt="" border=0 height="25" width="25"> 
		  <td><font color="#000000">ChainX<br><b>PCX</b></font></td>
          <td><font color="#000000">$0.83</font></td>
          <td><font color="#000000">$68,530,128.00</td>
           <td><a href="app/exchange.php" class="btn btn-sm btn-success">Trade</a></td>                           
                     
        </tr>
            
          </tbody>
        </table>
      </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




 <!-- Footer Contact Area -->
    <div class="footer-contact-area section-padding-100-50">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Footer Widget -->
                <div class="col-sm-4 col-md-5">
                    <div class="footer-single-widget first mb-50">
                        <div class="footer-logo">
                            <a href="#"><img src="img/footer-logo.png" alt=""></a>
                        </div>
                        <p class="mt-30">Exchange and Trading</p>

                        <div class="footer-form">
                            
                        </div>

                    </div>
                </div>

                <div class="col-sm-8 col-md-7">
                    <div class="row">
                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>LEGAL</h4>
                                <ul>
                                    <li><a href="aml-cft-policy.php">AML&amp;CFT Policy</a></li>
                                            <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                            <li><a href="risk-warning.php">Risk Warning</a></li>
                                            <li><a href="terms-of-services.php">Term of Services</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>SERVICES</h4>
                                <ul>
                                    <li><a href="app/exchange.php">Exchange</a></li>
                                    <li><a href="market.php">Markets</a></li>
                                    <li><a href="app/referrals.php">Referral Program</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-12 col-md-6 col-xl-4">
                            <div class="footer-single-widget mb-50">
                                <h4>Contact info</h4>
                                <ul>
                                    
                                    <li><a href="#"><i class="ti-email"></i>support@qingswap.com</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Contact Area -->

    <!-- Copy Right Area -->
    <div class="copy-right-area">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Copy Right Content -->
                <div class="col-md-6 text-center">
                    <div class="copy-right-content">
                        <p>Copyright © By Qingswap 2023. All right reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="//code.tidio.co/bpnp4xkz2axqrebqxcezgdca9yot1iyn.js" async></script>    <!-- JS here -->
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/jquery.animatedheadline.min.js"></script>
    <script src="js/date-time.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/bundle.js"></script>


    <!-- Custom js-->
    <script src="js/main.js"></script>


</body>


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:12:09 GMT -->
</html>