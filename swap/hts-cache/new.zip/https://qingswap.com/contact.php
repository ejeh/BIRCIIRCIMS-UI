


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:11:44 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Qingswap - Exchange and Trading</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

    <!-- All CSS Plugins here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/jquery.animatedheadline.css">

    <!-- Custom Css File -->
    <link rel="stylesheet" href="css/classy-nav.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="onitaNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="index.html"><img src="img/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- Menu Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="market.php">Market</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="auth/login.php">Login</a></li>
                                <li><a href="auth/register.php">Register</a></li>
                                <li>
                                    <style type="text/css">
                a.gflag {
                  vertical-align: middle;
                  font-size: 16px;
                  padding: 1px 0;
                  background-repeat: no-repeat;
                  background-image: url(//gtranslate.net/flags/16.png);
                }
                a.gflag img {
                  border: 0;
                }
                a.gflag:hover {
                  background-image: url(//gtranslate.net/flags/16a.png);
                }
                #goog-gt-tt {
                  display: none !important;
                }
                .goog-te-banner-frame {
                  display: none !important;
                }
                .goog-te-menu-value:hover {
                  text-decoration: none !important;
                }
                body {
                  top: 0 !important;
                }
                #google_translate_element2 {
                  display: none !important;
                }
              </style>

              <br /><select onchange="doGTranslate(this);">
                <option value="">Select Language</option>
                <option value="en|zh-CN">Chinese (Simplified)</option>
                <option value="en|zh-TW">Chinese (Traditional)</option>
                <option value="en|en">English</option>
              </select>
              <div id="google_translate_element2"></div>
              <script type="text/javascript">
                function googleTranslateElementInit2() {
                  new google.translate.TranslateElement(
                    { pageLanguage: "en", autoDisplay: false },
                    "google_translate_element2"
                  );
                }
              </script>
              <script
                type="text/javascript"
                src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"
              ></script>

              <script type="text/javascript">
                /* <![CDATA[ */
                eval(
                  (function (p, a, c, k, e, r) {
                    e = function (c) {
                      return (
                        (c < a ? "" : e(parseInt(c / a))) +
                        ((c = c % a) > 35
                          ? String.fromCharCode(c + 29)
                          : c.toString(36))
                      );
                    };
                    if (!"".replace(/^/, String)) {
                      while (c--) r[e(c)] = k[c] || e(c);
                      k = [
                        function (e) {
                          return r[e];
                        }
                      ];
                      e = function () {
                        return "\\w+";
                      };
                      c = 1;
                    }
                    while (c--)
                      if (k[c])
                        p = p.replace(
                          new RegExp("\\b" + e(c) + "\\b", "g"),
                          k[c]
                        );
                    return p;
                  })(
                    "6 7(a,b){n{4(2.9){3 c=2.9(\"o\");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s('t'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a=='')v;3 b=a.w('|')[1];3 c;3 d=2.x('y');z(3 i=0;i<d.5;i++)4(d[i].A=='B-C-D')c=d[i];4(2.j('k')==E||2.j('k').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,'m');7(c,'m')}}",
                    43,
                    43,
                    "||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500".split(
                      "|"
                    ),
                    0,
                    {}
                  )
                );
                /* ]]> */
              </script>
                                </li>
                            </ul>
                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Area End -->
<section class="contact-our-area section-padding-100-0" id="contact">
        <div class="container">
            <div class="row align-items-center mb-70">
                <div class="col-md-7 col-lg-5">
                    <div class="section-heading">
                        <h4>Contact Us</h4>
                    </div>
                </div>

                <div class="col-md-5 col-lg-7">
                    <div class="heading-btn">
                        <a href="#">Contact <i class="ti-angle-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
         

                <div class="col-lg-7">
                    <!-- Contact Form -->
                    <div class="contact_from_area clearfix mb-100">
                        <div class="contact_form">
                            <form action="contact.php" method="post" id="main_contact_form">
                                <div class="contact_input_area">
                                    <div id="success_fail_info"></div>
                                    <div class="row">
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control mb-30" name="name" id="name" placeholder="Name" required="">
                                            </div>
                                        </div>

                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="email" class="form-control mb-30" name="email" id="email" placeholder="E-mail" required="">
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control mb-30" name="subject" id="subject" placeholder="Subject">
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12">
                                            <div class="form-group">
                                                <textarea name="message" class="form-text-area mb-30" id="message" cols="30" rows="6" placeholder="Your Message *" required=""></textarea>
                                            </div>
                                        </div>
                                        <!-- Button -->
                                        <div class="col-12 text-center">
                                            <button type="submit" name="submit" class="btn boxed-btn">Send Message</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



<!-- Footer Contact Area -->
    <div class="footer-contact-area section-padding-100-50">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Footer Widget -->
                <div class="col-sm-4 col-md-5">
                    <div class="footer-single-widget first mb-50">
                        <div class="footer-logo">
                            <a href="#"><img src="img/footer-logo.png" alt=""></a>
                        </div>
                        <p class="mt-30">Exchange and Trading</p>

                        <div class="footer-form">
                            
                        </div>

                    </div>
                </div>

                <div class="col-sm-8 col-md-7">
                    <div class="row">
                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>LEGAL</h4>
                                <ul>
                                    <li><a href="aml-cft-policy.php">AML&amp;CFT Policy</a></li>
                                            <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                            <li><a href="risk-warning.php">Risk Warning</a></li>
                                            <li><a href="terms-of-services.php">Term of Services</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>SERVICES</h4>
                                <ul>
                                    <li><a href="app/exchange.php">Exchange</a></li>
                                    <li><a href="market.php">Markets</a></li>
                                    <li><a href="app/referrals.php">Referral Program</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-12 col-md-6 col-xl-4">
                            <div class="footer-single-widget mb-50">
                                <h4>Contact info</h4>
                                <ul>
                                    
                                    <li><a href="#"><i class="ti-email"></i>support@qingswap.com</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Contact Area -->

    <!-- Copy Right Area -->
    <div class="copy-right-area">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Copy Right Content -->
                <div class="col-md-6 text-center">
                    <div class="copy-right-content">
                        <p>Copyright © By Qingswap 2023. All right reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="//code.tidio.co/bpnp4xkz2axqrebqxcezgdca9yot1iyn.js" async></script>    <!-- JS here -->
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/jquery.animatedheadline.min.js"></script>
    <script src="js/date-time.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/bundle.js"></script>


    <!-- Custom js-->
    <script src="js/main.js"></script>


</body>


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:12:09 GMT -->
</html>