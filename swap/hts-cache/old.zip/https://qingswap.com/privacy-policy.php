


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:11:44 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Qingswap - Exchange and Trading</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

    <!-- All CSS Plugins here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/jquery.animatedheadline.css">

    <!-- Custom Css File -->
    <link rel="stylesheet" href="css/classy-nav.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="onitaNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="index.html"><img src="img/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- Menu Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="market.php">Market</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="auth/login.php">Login</a></li>
                                <li><a href="auth/register.php">Register</a></li>
                                <li>
                                    <style type="text/css">
                a.gflag {
                  vertical-align: middle;
                  font-size: 16px;
                  padding: 1px 0;
                  background-repeat: no-repeat;
                  background-image: url(//gtranslate.net/flags/16.png);
                }
                a.gflag img {
                  border: 0;
                }
                a.gflag:hover {
                  background-image: url(//gtranslate.net/flags/16a.png);
                }
                #goog-gt-tt {
                  display: none !important;
                }
                .goog-te-banner-frame {
                  display: none !important;
                }
                .goog-te-menu-value:hover {
                  text-decoration: none !important;
                }
                body {
                  top: 0 !important;
                }
                #google_translate_element2 {
                  display: none !important;
                }
              </style>

              <br /><select onchange="doGTranslate(this);">
                <option value="">Select Language</option>
                <option value="en|zh-CN">Chinese (Simplified)</option>
                <option value="en|zh-TW">Chinese (Traditional)</option>
                <option value="en|en">English</option>
              </select>
              <div id="google_translate_element2"></div>
              <script type="text/javascript">
                function googleTranslateElementInit2() {
                  new google.translate.TranslateElement(
                    { pageLanguage: "en", autoDisplay: false },
                    "google_translate_element2"
                  );
                }
              </script>
              <script
                type="text/javascript"
                src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"
              ></script>

              <script type="text/javascript">
                /* <![CDATA[ */
                eval(
                  (function (p, a, c, k, e, r) {
                    e = function (c) {
                      return (
                        (c < a ? "" : e(parseInt(c / a))) +
                        ((c = c % a) > 35
                          ? String.fromCharCode(c + 29)
                          : c.toString(36))
                      );
                    };
                    if (!"".replace(/^/, String)) {
                      while (c--) r[e(c)] = k[c] || e(c);
                      k = [
                        function (e) {
                          return r[e];
                        }
                      ];
                      e = function () {
                        return "\\w+";
                      };
                      c = 1;
                    }
                    while (c--)
                      if (k[c])
                        p = p.replace(
                          new RegExp("\\b" + e(c) + "\\b", "g"),
                          k[c]
                        );
                    return p;
                  })(
                    "6 7(a,b){n{4(2.9){3 c=2.9(\"o\");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s('t'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a=='')v;3 b=a.w('|')[1];3 c;3 d=2.x('y');z(3 i=0;i<d.5;i++)4(d[i].A=='B-C-D')c=d[i];4(2.j('k')==E||2.j('k').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,'m');7(c,'m')}}",
                    43,
                    43,
                    "||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500".split(
                      "|"
                    ),
                    0,
                    {}
                  )
                );
                /* ]]> */
              </script>
                                </li>
                            </ul>
                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

<br>
 <br>
 <br>
 <br>
 <br>
 <br>

<section class="testimonial" style="color: black">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                       
                        
                       <p class="card-text mb-3" >1. The purpose of this Privacy Policy is to inform you and provide you with an understanding of how Mek Global Limited (“<strong>Qingswap</strong>” or “<strong>we</strong>” or “<strong>us</strong>” or “<strong>our</strong>”) handles, collects, uses, discloses and deals with personal data about you (“<strong>User</strong>”) that you give us, that we receive through third parties or that is in our possession. Further, this Privacy Policy governs the manner in which Qingswap collects, uses, maintains and/or discloses personal data collected from Users of the <strong><a href="Qingswap.com" target="_blank" rel="noopener">Qingswap.com</a></strong> website (“<strong>Site</strong>”). To provide you with our Services, we might need (and sometimes obliged by the law) to collect your personal data.</p>
<div>

<p class="card-text mb-3" >2. We take our responsibilities under the Constitution of United States of Amerie seriously. We also recognize the importance of the personal data you have entrusted to us and believe that it is our responsibility to properly manage, protect and process your personal data.</p>

<p class="card-text mb-3" >3. This privacy policy applies to the Site and all Services offered by Qingswap.</p>

<h3 class="card-text mb-2" style="color:black">Personally identifiable information</h3>

<p class="card-text mb-3" >4. We may collect personally identifiable information from Users in a variety of ways, including, but not limited to, when Users visit our Site, register on the Site, place an order, and in connection with other activities, services, features or resources we make available on our Site. Users may be asked for, as appropriate, name, email address, mailing address, phone number. Users may, however, visit our Site anonymously. When interacting with us on the Site, Users can always refuse to supply personal data to us, except that it may prevent them from engaging in certain Site related activities or transactions.</p>

<h3 class="card-text mb-2" style="color:black">Non-personally identifiable information</h3>

<p class="card-text mb-3" >5. We may collect non-personally identifiable information about Users when they interact with our Site.</p>

<h3 class="card-text mb-2" style="color:black">What Information Do We Collect?</h3>

<p class="card-text mb-3" >6. “Personal data” used in this Privacy Policy is to mean data, whether true or not, about an individual who can be identified from that data, or from that data and other information to which an organization has or is likely to have access. Qingswap collects information about you when you use our websites (including the Site) and other online products and services and throughout other interactions and services you have with us. Personal data which we may collect include:</p>
<p>1. Name</p>
<p>2. Home Address</p>
<p>3. Contact Information</p>
<p>4. Transactional Information</p>
<p>5. Usage and Preferences</p>
<p>6. Identification number</p>
<p class="card-text mb-3" >7. Bank Account Number</p>

<p class="card-text mb-3" >We will collect your personal data in accordance with the legislative purpose of the DPA.</p>

<p class="card-text mb-3" >7. We may also collect and store certain information automatically when you visit the Site. Examples include the internet protocol (IP) address used to connect your computer or device to the internet, connection information such as browser type and version, your operating system and platform, a unique reference number linked to the data you enter on our system, login details, the full URL clickstream to, through and from the Site (including date and time), cookie number and your activity on our Site, including the pages you visited, the searches you made and, if relevant, the products/services you purchased.</p>

<p class="card-text mb-3" >8. We may receive information about you from third parties if you use any websites or social media platforms operated by third parties (for example, Facebook, Instagram, Twitter etc.) and, if such functionality is available, you have chosen to link your profile on the Site with your profile on those other websites or social media platforms.</p>

<h3 class="card-text mb-2" style="color:black">Cookies</h3>

<p class="card-text mb-3" >9. We may use cookies to identify you from other users on the Site.</p>

<p class="card-text mb-3" >10. A cookie is a small file of letters and numbers that we store on your browser or the hard drive of your computer or device.</p>

<p class="card-text mb-3" >11. You can block or deactivate cookies in your browser settings.</p>

<p class="card-text mb-3" >12. We use log-in cookies in order to remember you when you have logged in for a seamless experience.</p>

<p class="card-text mb-3" >13. We use session cookies to track your movements from page to page and in order to store your selected inputs so you are not constantly asked for the same information.</p>

<p class="card-text mb-3" >14. This Site uses Google Analytics which is one of the most widespread and trusted analytics solution on the web for helping us to understand how you use the Site and ways that we can improve your experience. These cookies may track things such as how long you spend on the Site and the pages that you visit so we can continue to produce engaging content.</p>

<p class="card-text mb-3" >15. By continuing to use the Site, you are agreeing to the use of cookies on the Site as outlined above. However, please note that we have no control over the cookies used by third parties.</p>

<p class="card-text mb-3" >16. For further information on types of cookies and how they work visit&nbsp;<u><a href="https://web.archive.org/web/20200918205601/http://www.allaboutcookies.org/" target="">www.allaboutcookies.org</a></u></p>

<p class="card-text mb-3" ><strong>Purposes For Collection, Use, Disclosure And Processing Of Your Personal Data</strong></p>

<p class="card-text mb-3" >17. Qingswap will/may collect, use, disclose and/or process your personal data for one or more of the following purposes:</p>

<p class="card-text mb-3" >(a) Administering, facilitating, processing and/or dealing in any matters relating to your use or access of the Site, including identifying you for login to the Site, our portals and other online services provided by or on behalf of us;</p>

<p class="card-text mb-3" >(b) Monitoring, processing and/or tracking your use of the Site in order to provide you with a seamless experience, facilitating or administering your use of the Site, and/or to assist us in improving your experience in using the Site;</p>

<p class="card-text mb-3" >(c) Assessing and processing your request for the purchase of and/or subscription to our products and/or services;</p>

<p class="card-text mb-3" >(d) Registering you as a customer of Qingswap and/or to deal with, process and/or administer the account that you may open with us, whether a membership account or otherwise, including to facilitate your transactions or activities on the Site, or your transactions or activities with us;</p>

<p>(e) Administering, facilitating, processing and/or dealing with your relationship with us, any transactions or activities carried out by you on the Site or with us. This includes processing your application, orders and payment transactions; implementing transactions and the supply of products and/or services to you that you have requested;</p>

<p class="card-text mb-3" >(f) Carrying out your instructions or responding to any enquiry given by (or purported to be given by) you or on your behalf including responding to your enquiries and complaints; or responding to or dealing with your interactions with us;</p>

<p class="card-text mb-3" >(g) Contacting you or communicating with you via phone/voice call, text message and/or fax message, email and/or postal mail for the purposes of administering and/or managing your use of the Site, your membership and/or account with us, your relationship with us or any transactions made by you with us. You acknowledge and agree that such communication by us could be by way of the mailing of correspondence, documents or notices to you, which could involve disclosure of certain personal data about you to bring about delivery of the same as well as on the external cover of envelopes/mail packages;</p>

<p class="card-text mb-3" >(h) Providing services to you as our account holder, as our customer, or when requested by you; dealing with or administering your participation in contests, gamification, social events organized by us;</p>

<p class="card-text mb-3" >(i) Understanding your interests, concerns and preferences;</p>

<p class="card-text mb-3" >(j) Identifying you and assisting you in your use of our products, services and website services;</p>

<p class="card-text mb-3" >(k) For marketing purpose and in this regard, we would be providing you with marketing, advertising and promotional information, materials and/or documents relating to products, contests, services and/or events (including those of third party organisations with which Qingswap may collaborate with) that Qingswap (including its affiliates/related corporations) or such third party organisations may be selling, marketing, offering, organizing, involved in or promoting, whether such products, services and/or events exist now or are created in the future:</p>

<p class="card-text mb-3" >(i) By way of postal mail, electronic transmission to your email address(es), and/or through other modes of communication that is not the 3 DNC Modes, in compliance with applicable local data protection law (i.e. the DPA). You may opt out of this or withdraw from this at any time by sending an email to our Data Protection Officer. For the avoidance of doubt, the application of or your acceptance of or your consent to, this Privacy Policy, constitutes your consent to this subparagraph (i);</p>

<p class="card-text mb-3" >(ii) If you have separately expressly consented to one or more of the following 3 DNC Modes, by way of the 3 modes of communications of voice calls, text messages or faxes (the “3 DNC Modes”) to your telephone number, in compliance with the requirements of applicable local data protection law (i.e. the DPA); and/or</p>

<p class="card-text mb-3" >(iii) Notwithstanding (ii) above, regardless that you have not separately provided express consent as aforementioned in (ii) above, Qingswap reserves its right to send a specified fax message and/or a specified text message (i.e. a marketing fax message or marketing text message) to your telephone number, to which Qingswap reserves the right for final interpretation;</p>

<p class="card-text mb-3" >(l) Carrying out due diligence or other screening activities (including background checks) in accordance with legal or regulatory obligations (whether United States of America or foreign country) applicable to us or our affiliates/associated companies, the requirements or guidelines of governmental authorities (whether United States of America or foreign country) which we determine are applicable to us or our affiliates/associated companies, and/or our risk management procedures that may be required by law (whether United States of America or foreign country) or that may have been put in place by us or our affiliates/associated companies;</p>

<p class="card-text mb-3" >(m) To prevent or investigate any fraud, unlawful activity or omission or misconduct, whether or not there is any suspicion of the aforementioned; dealing with conflict of interests; or dealing with and/or investigating complaints;</p>

<p class="card-text mb-3" >(n) Complying with or as required by any applicable law, court order, order of a regulatory body, governmental or regulatory requirements, of any jurisdiction applicable to us or our affiliates/associated companies, including meeting the requirements to make disclosure under the requirements of any law binding on us or our affiliates/associated companies, and/or for the purposes of any guidelines issued by regulatory or other authorities (whether of United States of America or elsewhere), with which we or our affiliates/associated companies are expected to comply;</p>

<p class="card-text mb-3" >(o) Complying with or as required by any request or direction of any governmental authority (whether United States of America or foreign country) which we are expected to comply with; or responding to requests for information from public agencies, ministries, statutory boards or other similar authorities (whether United States of America or foreign country). For the avoidance of doubt, this means that we may/will disclose your personal data to such parties upon their request or direction;</p>

<p class="card-text mb-3" >(p) Conducting research (including customer research), surveys, market surveys, analysis and/or development activities (including but not limited to data analytics, surveys and/or profiling) to improve our services and facilities, or to improve our understanding of your interests, concerns and preferences, in order to enhance any continued interaction between yourself and us connected or in relation to the Site, or improve any of our products or services;</p>

<p class="card-text mb-3" >(q) Storing, hosting, backing up (whether for disaster recovery or otherwise) of your personal data, whether within or outside United States of America;</p>

<p class="card-text mb-3" >(r) Facilitating, dealing with and/or administering external audit(s) or internal audit(s) of the business of Qingswap or that of its affiliates/related corporations;</p>

<p class="card-text mb-3" >(s) To create reports with respect to our transactions with you, and/or producing statistics and research of such transactions for internal and/or statutory reporting and/or record-keeping requirements;</p>

<p class="card-text mb-3" >(t) Dealing with and/or facilitating a business asset transaction or a potential business asset transaction, where such transaction involves Qingswap as a participant or involves only a related corporation or affiliated company of Qingswap as a participant or involves Qingswap and/or any one or more of Qingswap’s related corporations or affiliated companies as participant(s), and there may be other third party organisations who are participants in such transaction. “<strong>business asset transaction</strong>” means the purchase, sale, lease, merger or amalgamation or any other acquisition, disposal or financing of an organisation or a portion of an organisation or of any of the business or assets of an organisation;</p>

<p class="card-text mb-3" >(u) Anonymization of your personal data. In this regard, you acknowledge that personal data that has been anonymized is no longer personal data and the requirements of applicable local data protection law (i.e. the DPA) would no longer apply to such anonymized data;</p>

<p class="card-text mb-3" >(v) Qingswap, Qingswap Group Companies’ reporting purposes including but not limited to reporting on Qingswap’s business performance (“<strong>Qingswap&nbsp;Group Companies</strong>” means Qingswap, its affiliates, related corporations and associated companies globally); including producing statistics and research for internal and/or statutory reporting and/or record-keeping requirements, of Qingswap or of its affiliates/related corporations; and/or</p>

<p class="card-text mb-3" >(the purposes set out above shall be collectively referred to as the “<strong>Purposes</strong>”).</p>

<p class="card-text mb-3" >18. Qingswap may/will need to disclose your personal data to third parties, whether located within or outside United States of America, for one or more of the above Purposes, as such third parties, would be processing your personal data for one or more of the above Purposes. In this regard, you hereby acknowledge, agree and consent that we may/are permitted to disclose your personal data to such third parties (whether located within or outside United States of America) for one or more of the above Purposes and for the said third parties to subsequently collect, use, disclose and/or process your personal data for one or more of the above Purposes. Without limiting the generality of the foregoing or of paragraph 17, such third parties include:</p>

<p class="card-text mb-3" >(a) Our associated or affiliated organisations or related corporations;</p>

<p class="card-text mb-3" >(b) Any of our agents, contractors or third party service providers that process or will be processing your personal data on our behalf including but not limited to those which provide administrative or other services to us such as mailing houses, telecommunication companies, information technology companies and data centres; and</p>

<p class="card-text mb-3" >(c) Third parties to whom disclosure by us is for one or more of the Purposes and such third parties would in turn be collecting and processing your personal data for one or more of the Purposes.</p>

<p class="card-text mb-3" >19. You may withdraw your consent for the collection, use and/or disclosure of your personal data in our possession or under our control by emailing us at&nbsp;<strong><a href="mailto:support@qingswap.com" target="_blank" rel="noopener">support@qingswap.com</a></strong>. We will process your request [within a reasonable time] from such a request for withdrawal of consent being made, and will thereafter not collect, use and/or disclose your personal data in the manner stated in your request, unless an exception under the law or a provision in the law permits us to. However, your withdrawal of consent could result in certain legal consequences arising from such withdrawal, including us being unable to perform the transactions requested by you in the Site.</p>

<p class="card-text mb-3" >20. We may collect, use, disclose or process your personal data for other purposes that do not appear above. However, we will notify you of such other purpose at the time of obtaining your consent, unless processing of your personal data without your consent is permitted by the DPA or by law.</p>

<p class="card-text mb-3" >21. We may/will also be collecting from sources other than yourself, personal data about you, for one or more of the above Purposes, and thereafter using, disclosing and/or processing such personal data for one or more of the above Purposes. We may combine information we receive from other sources with information you give to us and information we collect about you. We may use this information and the combined information for the Purposes set out above (depending on the types of information we receive).</p>

<h3 class="card-text mb-2" style="color:black">How we protect your personal data</h3>

<p class="card-text mb-3" >22. We adopt appropriate data collection, storage and processing practices and security measures to protect against unauthorized access, alteration, disclosure or destruction of your personal data, username, password, transaction information and data stored on our Site.</p>

<p class="card-text mb-3" >23. Sensitive and private data exchange between the Site and its Users happens over a SSL secured communication channel and is encrypted and protected with digital signatures. Our Site is functioning in compliance with PCI vulnerability standards in order to create as secure of an environment as possible for Users.</p>

<p class="card-text mb-3" >24. We will put in place measures such that your personal data in our possession or under our control is destroyed and/or anonymized as soon as it is reasonable to assume that (i) the purpose for which that personal data was collected is no longer being served by the retention of such personal data; and (ii) retention is no longer necessary for any other legal or business purposes.</p>

<h3 class="card-text mb-2" style="color:black">Sharing your personal information</h3>

<p class="card-text mb-3" >25. We do not sell, trade, or rent Users’ personally identifiable information to others. We may share generic aggregated demographic information not linked to any personally identifiable information regarding visitors and users with our business partners, trusted affiliates and advertisers for the purposes outlined above.</p>

<h3 class="card-text mb-2" style="color:black">Rights</h3>

<p class="card-text mb-3" >26. You have the right to ask us not to use your personal data for marketing purposes. Please let us know if you want to withdraw your consent by emailing us at <strong><a href="mailto:support@qingswap.com" target="_blank" rel="noopener">support@qingswap.com</a></strong>.</p>

<p class="card-text mb-3" >27. You have the right to access and/or correct any personal data that we hold about you, subject to exceptions under the law. This right can be exercised at any time by emailing us at <strong><a href="mailto:support@qingswap.com" target="_blank" rel="noopener">support@qingswap.com</a></strong>. We will need enough information from you in order to ascertain your identity as well as the nature of your request, so as to be able to deal with your request. With respect to your access request, we may charge a fee in order to process it.</p>

<p class="card-text mb-3" >28. For a request to access personal data, once we have sufficient information from you to deal with the request, we will seek to provide you with the relevant personal data within 30 days. Where we are unable to respond to you within the said 30 days, we will notify you of the soonest possible time within which we can provide you with the information requested.</p>

<p class="card-text mb-3" >29. For a request to correct personal data, once we have sufficient information from you to deal with the request, we will correct your personal data within 30 days. Where we are unable to do so within the said 30 days, we will notify you of the soonest practicable time within which we can make the correction. We will send the corrected personal data to every other organization to which the personal data was disclosed by us within a year before the date the correction was made, unless that other organization does not need the corrected personal data for any legal or business purpose.</p>

<p class="card-text mb-3" >30. We hold and deal with your data in accordance with the DPA.</p>

<h3  class="card-text mb-2" style="color:black">Complaint Process</h3>

<p class="card-text mb-3" >31. If you have any complaint or grievance regarding about how we are handling your personal data or about how we are complying with the DPA (when in force), we welcome you to contact us with your complaint or grievance.</p>

<p class="card-text mb-3" >32. Please contact us with your complaint or grievance by emailing us at <strong><a href="mailto:support@qingswap.com" target="_blank" rel="noopener">support@qingswap.com</a></strong>.</p>

<p class="card-text mb-3" >33. Where you are sending an email in which you are submitting a complaint, your indication at the subject header that it is a DPA complaint would assist us in attending to your complaint speedily by passing it on to the relevant staff in our organization to handle. For example, you could insert the subject header as “DPA Complaint”.</p>

<p class="card-text mb-3" >34. We will certainly strive to deal with any complaint or grievance that you may have speedily and fairly.</p>

<h3 class="card-text mb-2" style="color:black">Changes to this privacy policy</h3>

<p class="card-text mb-3" >35. Qingswap has the discretion to update this privacy policy at any time. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>

<h3  class="card-text mb-2" style="color:black">Your acceptance of these terms</h3>

<p class="card-text mb-3" >36. By using this Site, you signify your acceptance of this policy and Terms of Use. If you do not agree to this policy, please do not use our Site.</p>

<h3 class="card-text mb-2" style="color:black">General</h3>

<p class="card-text mb-3" >37. Your consent that is given pursuant to this Privacy Policy is additional to and does not supercede any other consents that you had provided to Qingswap with regard to processing of your personal data.</p>

<p class="card-text mb-3" >38. For the avoidance of doubt, in the event that United States of America data protection law permits an organisation such as us to collect, use or disclose your personal data without your consent, such permission granted by the law shall continue to apply.</p>

<p class="card-text mb-3" >If you have any queries on this Privacy Policy or any other queries in relation to how we may manage, protect and/or process your personal data, please do not hesitate to contact our Data Protection Officer at&nbsp;<strong><u><a href="mailto:support@qingswap.com" target="_self" rel="undefined">support@qingswap.com</a></u></strong>.</p>
                                    </div>
                                </div><!-- end input-group -->
                            </form>
                        </div>
                    </div><!-- end card -->
                    
                    
                </div><!-- end sidebar -->
            </div><!-- end col-lg-4 -->
        </div><!-- end row -->
    </div>
</section>


<!-- Footer Contact Area -->
    <div class="footer-contact-area section-padding-100-50">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Footer Widget -->
                <div class="col-sm-4 col-md-5">
                    <div class="footer-single-widget first mb-50">
                        <div class="footer-logo">
                            <a href="#"><img src="img/footer-logo.png" alt=""></a>
                        </div>
                        <p class="mt-30">Exchange and Trading</p>

                        <div class="footer-form">
                            
                        </div>

                    </div>
                </div>

                <div class="col-sm-8 col-md-7">
                    <div class="row">
                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>LEGAL</h4>
                                <ul>
                                    <li><a href="aml-cft-policy.php">AML&amp;CFT Policy</a></li>
                                            <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                            <li><a href="risk-warning.php">Risk Warning</a></li>
                                            <li><a href="terms-of-services.php">Term of Services</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-6 col-lg-3">
                            <div class="footer-single-widget mb-50">
                                <h4>SERVICES</h4>
                                <ul>
                                    <li><a href="app/exchange.php">Exchange</a></li>
                                    <li><a href="market.php">Markets</a></li>
                                    <li><a href="app/referrals.php">Referral Program</a></li>
                                  </ul>
                            </div>
                        </div>

                        <!-- Footer Widget -->
                        <div class="col-12 col-md-6 col-xl-4">
                            <div class="footer-single-widget mb-50">
                                <h4>Contact info</h4>
                                <ul>
                                    
                                    <li><a href="#"><i class="ti-email"></i>support@qingswap.com</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Contact Area -->

    <!-- Copy Right Area -->
    <div class="copy-right-area">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Copy Right Content -->
                <div class="col-md-6 text-center">
                    <div class="copy-right-content">
                        <p>Copyright © By Qingswap 2023. All right reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="//code.tidio.co/bpnp4xkz2axqrebqxcezgdca9yot1iyn.js" async></script>    <!-- JS here -->
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrollIt.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/nice-select.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/jquery.animatedheadline.min.js"></script>
    <script src="js/date-time.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/bundle.js"></script>


    <!-- Custom js-->
    <script src="js/main.js"></script>


</body>


<!-- Mirrored from demo.riktheme.com/nafton/landing-new/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Feb 2023 03:12:09 GMT -->
</html>