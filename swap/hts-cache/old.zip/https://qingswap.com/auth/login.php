




             <style type="text/css">
                a.gflag {
                  vertical-align: middle;
                  font-size: 16px;
                  padding: 1px 0;
                  background-repeat: no-repeat;
                  background-image: url(//gtranslate.net/flags/16.png);
                }
                a.gflag img {
                  border: 0;
                }
                a.gflag:hover {
                  background-image: url(//gtranslate.net/flags/16a.png);
                }
                #goog-gt-tt {
                  display: none !important;
                }
                .goog-te-banner-frame {
                  display: none !important;
                }
                .goog-te-menu-value:hover {
                  text-decoration: none !important;
                }
                body {
                  top: 0 !important;
                }
                #google_translate_element2 {
                  display: none !important;
                }
              </style>

              <br /><select onchange="doGTranslate(this);">
                <option value="">Select Language</option>
                <option value="en|zh-CN">Chinese (Simplified)</option>
                <option value="en|zh-TW">Chinese (Traditional)</option>
                <option value="en|en">English</option>
              </select>
              <div id="google_translate_element2"></div>
              <script type="text/javascript">
                function googleTranslateElementInit2() {
                  new google.translate.TranslateElement(
                    { pageLanguage: "en", autoDisplay: false },
                    "google_translate_element2"
                  );
                }
              </script>
              <script
                type="text/javascript"
                src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"
              ></script>

              <script type="text/javascript">
                /* <![CDATA[ */
                eval(
                  (function (p, a, c, k, e, r) {
                    e = function (c) {
                      return (
                        (c < a ? "" : e(parseInt(c / a))) +
                        ((c = c % a) > 35
                          ? String.fromCharCode(c + 29)
                          : c.toString(36))
                      );
                    };
                    if (!"".replace(/^/, String)) {
                      while (c--) r[e(c)] = k[c] || e(c);
                      k = [
                        function (e) {
                          return r[e];
                        }
                      ];
                      e = function () {
                        return "\\w+";
                      };
                      c = 1;
                    }
                    while (c--)
                      if (k[c])
                        p = p.replace(
                          new RegExp("\\b" + e(c) + "\\b", "g"),
                          k[c]
                        );
                    return p;
                  })(
                    "6 7(a,b){n{4(2.9){3 c=2.9(\"o\");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s('t'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a=='')v;3 b=a.w('|')[1];3 c;3 d=2.x('y');z(3 i=0;i<d.5;i++)4(d[i].A=='B-C-D')c=d[i];4(2.j('k')==E||2.j('k').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,'m');7(c,'m')}}",
                    43,
                    43,
                    "||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500".split(
                      "|"
                    ),
                    0,
                    {}
                  )
                );
                /* ]]> */
              </script>
<!DOCTYPE html>
<html lang="en" class="h-100">


<!-- Mirrored from tixia.dexignzone.com/xhtml/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 17 Feb 2023 03:08:21 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="Qingswap" />
    <meta name="robots" content="index, follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Qingswap - Login </title>
    <!-- Favicon icon -->
    <link rel="shortcut icon" type="image/png" href="../app/images/favicon.png" />
  <link href="../app/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
  <link href="../app/css/style.css" rel="stylesheet">
  <link href="../app/vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <div class="text-center mb-3">
                                        <a href="../index.php"><img src="../app/images/logo-full.png" alt=""></a>
                                    </div>
                                    <h4 class="text-center mb-4">Sign in your account</h4>
                                    <form id="loginfrm">
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Username</strong></label>
                                            <input type="username" name="username" id="username" class="form-control" placeholder ="Eg. ABC">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" name="password" id="password" class="form-control" placeholder="******">
                                        </div>
                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <div class="form-group">
                                               
                                            </div>
                                            <div class="form-group">
                                                <a href="forgot-password.php">Forgot Password?</a>
                                            </div>
                                        </div>
                                        <input type="hidden" name="ModType" value="LoginFrm">
                                        <div class="text-center">
                                            <button type="button" id="submitbtn" onclick="loginBtn(this)" class="btn btn-primary btn-block">Sign Me In</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Don't have an account? <a class="text-primary" href="register.php">Sign up</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

      <script type="text/javascript">
    function loginBtn(){
      var form =  document.getElementById('loginfrm');
      var formData = new FormData(form);
      var username = $('#username').val();
      var password = $('#password').val();

      if (username != "" && password != "") {
        if (username == '') {
          sweetAlert("Oops...", "Input your username", "error");
        }else if(password = ""){
          sweetAlert("Oops...", "Your password is needed", "error");
        }else{
          $.ajax({
            type: 'POST',
            url: 'action.php',
            contentType:false,
            processData: false,
            data: formData,
            beforeSend: function(){
             $('#submitbtn').html("<i class='fa fa-spinner'></i>") ;
              $('#submitbtn').attr('onclick', '') ; 
            },
            success: function(data){
              // Do something on success
               $('#submitbtn').attr('onclick', 'loginBtn()') ; 
               if(data == 1){
                sweetAlert(
                  "Bravo", "Succesfully Logged In, click OK to continue", "success"
                  ).then((result) => {
                      window.location.href = '../app/'
                  })
               }else{
                  sweetAlert("Oops...", data, "error");
                  $('#submitbtn').html('Sign Me In') ;
                } 
              }
            });
        }
      }else{
        sweetAlert("Oops...", "Invalid", "error");
      }
    }
  </script>

<script src="//code.tidio.co/bpnp4xkz2axqrebqxcezgdca9yot1iyn.js" async></script>    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
  <script src="../app/vendor/global/global.min.js"></script>
  <script src="../app/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
  <script src="../app/js/custom.min.js"></script>
  <script src="../app/js/deznav-init.js"></script>
  <!-- <script src="../app/js/styleSwitcher.js"></script> -->

  <script src="../app/vendor/sweetalert2/dist/sweetalert2.min.js"></script>
  <script src="../app/js/plugins-init/sweetalert.init.js"></script>

</body>


<!-- Mirrored from tixia.dexignzone.com/xhtml/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 17 Feb 2023 03:08:22 GMT -->
</html>